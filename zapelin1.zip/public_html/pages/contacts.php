<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>

<p><h1 style="text-align:center">Контакты</h1></p>
<p style="height:100px; text-align:center;"><br>Для связи с технической поддержкой по вопросам работы нашего проекта, используйте реквизиты указанные ниже! <br>
Перед обращением укажите в письме свой логин (payeer кошелек). <strong><span class="style1"><?=$adminmail?> (E-mail техподдержки)</b></span></strong><br>








