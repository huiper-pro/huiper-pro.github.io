﻿<?
if(!defined('SCRIPT_BY_SIRGOFFAN')){
exit();
}
?>



 
</div>
	
<div id="footer_wrapper" class="">
    <div id="footer_top">
        <div class="footer_container">
           
            <div class="footer_block lastblock">
                <ul>
                    <li class="first seen"><span>Навигация по сайту</span></li>
                    <li class="seen"><a href="/?page=rules">Правила проекта</a></li>
                    <li class="seen"><a href="/?page=referals">Партнерская программа</a></li>
                    <li class="seen"><a href="/?page=contacts">Техническая поддержка</a></li>

				</ul>
            </div>

            <div class="footer_block soc_links">
                <div class="fl_left">
                    <a title="vk.com" class="vk_link circle_link" href=""></a>
                </div>
                <div class="fl_left">
                    <a title="facebook.com" class="fb_link circle_link" href=""></a>
                </div>
                <div class="fl_left">
                    <a title="twitter.com" class="tw_link circle_link" href=""></a>
                </div>
            </div>


            <div class="footer_right">
                <div id="footer_logo">
                   
                    <div class="security">
            	<div class="security-one">
                	<a href="#"><img src="/img/comodo.png"></a>
                </div>
                <div class="security-one">
                	<a href="#"><img src="/img/ddos.png"></a>
                </div>
                
            
            </div>
                </div>
      
            </div>
            <div class="blank"></div>
        </div>
    </div>
    <div id="footer_bottom">
        <div id="footer_bottom_line"></div>
        <div id="footer_bottom_content">
            <div class="footer_container">
                <div id="footer_copyright">
           <span>zeppelin-cars.ru © 2017 Все права защищены!</span>
                </div>
                <div id="footer_counters">
                    <div class="webmoney_info">
                        <div class="f_right">
<!--LiveInternet counter--><script type="text/javascript"><!--
document.write("<a href='//www.liveinternet.ru/click' "+
"target=_blank><img src='//counter.yadro.ru/hit?t14.6;r"+
escape(document.referrer)+((typeof(screen)=="undefined")?"":
";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?
screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+
";"+Math.random()+
"' alt='' title='LiveInternet: показано число просмотров за 24"+
" часа, посетителей за 24 часа и за сегодня' "+
"border='0' width='88' height='31'><\/a>")
//--></script><!--/LiveInternet-->
<img src="/img/payeer.png" border="0">
                        </div>
                        <div class="f_right f_right_margin">
                           



							                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
	
 <script id="hiddenlpsubmitdiv" style="display: none;"></script><script>try{(function() { for(var lastpass_iter=0; lastpass_iter < document.forms.length; lastpass_iter++){ var lastpass_f = document.forms[lastpass_iter]; if(typeof(lastpass_f.lpsubmitorig2)=="undefined"){ lastpass_f.lpsubmitorig2 = lastpass_f.submit; if (typeof(lastpass_f.lpsubmitorig2)=='object'){ continue;}lastpass_f.submit = function(){ var form=this; var customEvent = document.createEvent("Event"); customEvent.initEvent("lpCustomEvent", true, true); var d = document.getElementById("hiddenlpsubmitdiv"); if (d) {for(var i = 0; i < document.forms.length; i++){ if(document.forms[i]==form){ if (typeof(d.innerText) != 'undefined') { d.innerText=i.toString(); } else { d.textContent=i.toString(); } } } d.dispatchEvent(customEvent); }form.lpsubmitorig2(); } } }})()}catch(e){}</script></body></html>